package bestia;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class EscapaDeLaBestia extends JFrame implements ActionListener, KeyListener {
    private int playerX, playerY; // Posición del jugador
    private int keyX, keyY; // Posición de la llave
    private int doorX, doorY; // Posición de la puerta
    private int crucifixX, crucifixY; // Posición del crucifijo en nivel 1
    private boolean hasKey = false;
    private boolean hasCrucifix = false;
    private int level = 0; // Nivel actual
    private boolean beastActive = false;
    private int beastX, beastY; // Posición de la bestia
    private boolean beastFrozen = false;
    private long freezeEndTime = 0;
    private int crucifixUses = 3; // Usos restantes del crucifijo

    private boolean moveUp, moveDown, moveLeft, moveRight;
    private GamePanel gamePanel;
    private boolean gameWon = false;
    private boolean gameOver = false;

    // Variables para las imágenes
    private Image playerImage;
    private Image keyImage;
    private Image doorImage;
    private Image beastImage;
    private Image crucifixImage;
    private Image backgroundImageLevel0;
    private Image backgroundImageLevel1;

    // Dimensiones del área jugable
    private static final int AREA_WIDTH_0 = 1550;
    private static final int AREA_HEIGHT_0 = 300;
    private static final int AREA_WIDTH_1 = 1550;
    private static final int AREA_HEIGHT_1 = 800;

    private int areaX = 25;
    private int areaY = 25;

    public EscapaDeLaBestia() {
        setTitle("Escapa de la Bestia");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1600, 900); // Tamaño de la ventana del juego
        setLocationRelativeTo(null);
        gamePanel = new GamePanel();
        add(gamePanel);
        setupLevel();

        Timer timer = new Timer(16, this);
        timer.start();

        gamePanel.setFocusable(true);
        gamePanel.requestFocusInWindow();
        gamePanel.addKeyListener(this);

        // Cargar las texturas
        try {
            playerImage = ImageIO.read(new File("resources/player.png"));
            keyImage = ImageIO.read(new File("resources/key.png"));
            doorImage = ImageIO.read(new File("resources/door.png"));
            beastImage = ImageIO.read(new File("resources/beast.png"));
            crucifixImage = ImageIO.read(new File("resources/crucifix.png"));
            backgroundImageLevel0 = ImageIO.read(new File("resources/background.png"));
            backgroundImageLevel1 = ImageIO.read(new File("resources/background1.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class GamePanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Dibujar el fondo dentro del área jugable
            Image backgroundImage = (level == 0) ? backgroundImageLevel0 : backgroundImageLevel1;

            // Verificar si la imagen de fondo está cargada correctamente
            if (backgroundImage != null) {
                g.drawImage(
                    backgroundImage,
                    areaX, areaY,
                    level == 0 ? AREA_WIDTH_0 : AREA_WIDTH_1,
                    level == 0 ? AREA_HEIGHT_0 : AREA_HEIGHT_1,
                    this
                );
            } else {
                System.out.println("Fondo no cargado correctamente.");
            }

            // Dibujar el rectángulo del área jugable
            g.setColor(Color.WHITE);
            g.drawRect(areaX, areaY,
                level == 0 ? AREA_WIDTH_0 : AREA_WIDTH_1,
                level == 0 ? AREA_HEIGHT_0 : AREA_HEIGHT_1
            );

            // Dibujar imágenes en lugar de formas sólidas
            g.drawImage(playerImage, playerX, playerY, 70, 100, this); // Tamaño ajustado del jugador
            g.drawImage(keyImage, keyX, keyY, 25, 25, this); // Tamaño ajustado de la llave
            g.drawImage(doorImage, doorX, doorY, 140, 200, this); // Tamaño ajustado de la puerta

            if (beastActive) {
                g.drawImage(beastImage, beastX, beastY, 100, 200, this); // Tamaño ajustado de la bestia
            }

            if (level == 1 && !hasCrucifix) {
                g.drawImage(crucifixImage, crucifixX, crucifixY, 30, 30, this); // Tamaño ajustado del crucifijo
            }

            if (beastFrozen) {
                g.setColor(Color.WHITE);
                g.drawString("Bestia congelada!", 350, 50);
            }

            if (gameWon) {
                g.setColor(Color.GREEN);
                g.drawString("¡Has ganado!", 350, 300);
            }

            if (hasCrucifix && crucifixUses > 0) {
                g.setColor(Color.WHITE);
                g.drawString("Usos de crucifijo: " + crucifixUses, 10, 50);
            }

            if (gameOver) {
                g.setColor(Color.RED);
                g.drawString("¡La bestia te ha atrapado!", 350, 300);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameWon && !gameOver) {
            if (moveUp && playerY > areaY) playerY -= 4;
            if (moveDown && playerY < areaY + (level == 0 ? AREA_HEIGHT_0 : AREA_HEIGHT_1) - 40) playerY += 4;
            if (moveLeft && playerX > areaX) playerX -= 4;
            if (moveRight && playerX < areaX + (level == 0 ? AREA_WIDTH_0 : AREA_WIDTH_1) - 40) playerX += 4;

            if (beastActive && !beastFrozen) {
                if (playerX < beastX) beastX -= 2;
                if (playerX > beastX) beastX += 2;
                if (playerY < beastY) beastY -= 2;
                if (playerY > beastY) beastY += 2;

                // Verificar si la bestia ha alcanzado al jugador
                if (playerX < beastX + 100 && playerX + 40 > beastX && playerY < beastY + 200 && playerY + 40 > beastY) {
                    gameOver = true; // Terminar el juego si la bestia toca al jugador
                }
            }

            if (beastFrozen && System.currentTimeMillis() >= freezeEndTime) {
                beastFrozen = false;
            }

            // Colisión con la llave
            if (playerX < keyX + 25 && playerX + 40 > keyX && playerY < keyY + 25 && playerY + 40 > keyY) {
                hasKey = true;
                keyX = -100;
            }

            // Colisión con la puerta
            if (hasKey && playerX < doorX + 140 && playerX + 40 > doorX && playerY < doorY + 200 && playerY + 40 > doorY) {
                if (level == 0) {
                    level = 1;
                    setupLevel();
                } else if (level == 1) {
                    gameWon = true;
                }
            }

            // Colisión con el crucifijo
            if (level == 1 && !hasCrucifix && playerX < crucifixX + 30 && playerX + 40 > crucifixX && playerY < crucifixY + 30 && playerY + 40 > crucifixY) {
                hasCrucifix = true;
                crucifixX = -100;
            }

            repaint();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W: moveUp = true; break;
            case KeyEvent.VK_S: moveDown = true; break;
            case KeyEvent.VK_A: moveLeft = true; break;
            case KeyEvent.VK_D: moveRight = true; break;
            case KeyEvent.VK_Q:
                if (hasCrucifix && crucifixUses > 0 && beastActive && !beastFrozen) {
                    beastFrozen = true;
                    freezeEndTime = System.currentTimeMillis() + 5000;
                    crucifixUses--;
                }
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W: moveUp = false; break;
            case KeyEvent.VK_S: moveDown = false; break;
            case KeyEvent.VK_A: moveLeft = false; break;
            case KeyEvent.VK_D: moveRight = false; break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    private void setupLevel() {
        playerX = 100;
        playerY = 100;
        keyX = 400;
        keyY = 100;
        doorX = 1200;
        doorY = 100;
        
        if (level == 1) {
            crucifixX = 800;
            crucifixY = 300;
            beastX = 700; // La bestia comienza en el nivel 1
            beastY = 200;
            beastActive = true; // Activamos la bestia solo en el nivel 1
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EscapaDeLaBestia().setVisible(true));
    }
}
